DEFAULT_SERVICE = 'requests'
