SETTINGS_SERVICE = 'datadog_trace_service'
SETTINGS_TRACER = 'datadog_tracer'
SETTINGS_TRACE_ENABLED = 'datadog_trace_enabled'
SETTINGS_DISTRIBUTED_TRACING = 'datadog_distributed_tracing'
