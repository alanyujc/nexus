CMD = "memcached.command"
SERVICE = "memcached"
TYPE = "memcached"
QUERY = "memcached.query"
