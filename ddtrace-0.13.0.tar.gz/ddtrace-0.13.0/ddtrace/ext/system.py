"""
Standard system tags
"""

PID = "system.pid"
