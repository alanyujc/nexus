class AppTypes(object):
    web = "web"
    db = "db"
    cache = "cache"
    worker = "worker"
